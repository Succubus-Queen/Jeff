package me.krickl.memebotj.Exceptions;

/**
 * This file is part of memebotj.
 * Created by unlink on 18/04/16.
 */
public class DatabaseReadException extends Exception {
    public DatabaseReadException(String message) {
        super(message);
    }
}
