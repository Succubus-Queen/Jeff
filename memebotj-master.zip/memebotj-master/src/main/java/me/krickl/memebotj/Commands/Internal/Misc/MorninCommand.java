package me.krickl.memebotj.Commands.Internal.Misc;

import me.krickl.memebotj.Channel.ChannelHandler;
import me.krickl.memebotj.Commands.CommandHandler;
import me.krickl.memebotj.Memebot;
import me.krickl.memebotj.User.UserHandler;
import me.krickl.memebotj.Utility.TextFormatting;

import java.security.SecureRandom;

/**
 * Created by lukas on 12/14/2016.
 */
public class MorninCommand extends CommandHandler {
    public MorninCommand(ChannelHandler channelHandler, String commandName, String dbprefix) {
        super(channelHandler, commandName, dbprefix);
    }

    @Override
    public void initCommand() {
        this.setEnabled(false);
    }

    @Override
    public void overrideDB() {
        this.setUserCooldownLength(10);

        this.setTextTrigger(true);
    }

    @Override
    public void commandScript(UserHandler sender, String[] data) {
        SecureRandom ran = new SecureRandom();

        if(ran.nextInt(100) <= 20 || Memebot.debug) {
            getChannelHandler().sendMessage(TextFormatting.format("MORNIN", getChannelHandler(), sender, this, true,
                    new String[]{}, ""), getChannelHandler().getChannel(), sender, isWhisper());
        }
    }
}
