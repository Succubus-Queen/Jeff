package me.krickl.memebotj.Exceptions;

/**
 * This file is part of memebotj.
 * Created by unlink on 29/04/16.
 */
public class ChusOnZException extends Exception {
    public ChusOnZException() {
        super("Keg Was Thrown");
    }
}
