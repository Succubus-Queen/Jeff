package me.krickl.memebotj.Commands.Interfaces;

import me.krickl.memebotj.Commands.CommandHandler;

/**
 * This file is part of memebotj.
 * Created by lukas on 10/6/2016.
 */
public interface IOverrideDatabase {
    void overrideDB(CommandHandler command);
}
