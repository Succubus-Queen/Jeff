package me.krickl.memebotj.Connection.Debug;

import me.krickl.memebotj.Channel.ChannelHandler;
import me.krickl.memebotj.Connection.Interfaces.IConnection;
import me.krickl.memebotj.Connection.Protocols;
import me.krickl.memebotj.Exceptions.LoginException;
import me.krickl.memebotj.User.UserHandler;
import me.krickl.memebotj.Utility.MessagePackage;

import java.io.IOException;
import java.util.Scanner;

/**
 * This file is part of memebotj.
 * Created by lukas on 12/13/2016.
 */
public class DebugConnectionHandler implements IConnection {
    @Override
    public void ping() throws IOException {

    }

    @Override
    public String recvData() throws LoginException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("DEBUG_INPUT>>");
        return scanner.nextLine();
    }

    @Override
    public MessagePackage handleMessage(String rawircmsg, ChannelHandler channelHandler) {
        MessagePackage dp = new MessagePackage(rawircmsg.split(" "), new UserHandler("unlink2", "#debug"),
                "PRIVMSG", "#memebot__", "debug");

        return dp;
    }

    @Override
    public void close() {

    }

    @Override
    public void sendMessage(String msg) {
        System.out.println(msg);
    }

    @Override
    public void sendMessageBytes(String msg) {
        System.out.println(msg);
    }

    @Override
    public String getBotNick() {
        return "debug__";
    }

    @Override
    public boolean canReceive() {
        return false;
    }

    @Override
    public Protocols botMode() {
        return null;
    }
}
