package me.krickl.memebotj.Commands.Internal.Misc;

import me.krickl.memebotj.Channel.ChannelHandler;
import me.krickl.memebotj.Commands.CommandHandler;
import me.krickl.memebotj.Memebot;
import me.krickl.memebotj.User.UserHandler;

/**
 * This file is part of memebotj.
 * Created by lukas on 9/23/2016.
 */
public class FullWidthConverterCommand extends CommandHandler {
    public FullWidthConverterCommand(ChannelHandler channelHandler, String commandName, String dbprefix) {
        super(channelHandler, commandName, dbprefix);
    }

    @Override
    public void overrideDB() {
        this.setEnabled(true);
        this.setUserCooldownLength(60);
    }

    @Override
    public void commandScript(UserHandler sender, String[] data) {
        String[] alphabetMap = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
        "r", "s", "t", "u", "v", "x", "y", "z",
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "o", "P", "Q", "R", "S", "T", "U", "V",
        "X", "y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
        String[] widthMap = {"ａ","ｂ", "ｚ", "ｄ", "ｅ", "ｆ", "ｇ", "ｈ", "ｉ", "ｊ", "ｋ", "ｌ" ,"ｍ", "ｎ", "ｏ", "ｐ", "ｑ",
                "ｒ", "ｓ", "ｔ", "ｕ", "ｖ", "ｘ", "ｙ", "ｚ",
                "Ａ", "Ｂ", "Ｚ", "Ｄ", "Ｅ", "Ｆ", "Ｇ", "Ｈ", "Ｉ", "Ｊ", "Ｋ", "Ｌ", "Ｍ", "Ｎ", "Ｏ", "Ｐ",
                "Ｑ", "Ｒ", "Ｓ", "Ｔ", "Ｕ", "Ｖ", "Ｘ", "Ｙ", "Ｚ", "０", "１", "２", "３", "４",
                "５", "６", "７", "８", "９"};
        String rawmessage = "";
        for(String s : data) {
            rawmessage = rawmessage + s + " ";
        }

        for(int i = 0; i < alphabetMap.length; i++) {
            if(rawmessage.contains(alphabetMap[i])) {
                rawmessage.replace(alphabetMap[i], widthMap[i] + " ");
            }
        }

        getChannelHandler().sendMessage(rawmessage, getChannelHandler().getChannel(), sender, isWhisper());
    }
}
