package me.krickl.memebotj.Connection.Discord;

/**
 * This file is part of memebotj.
 * Created by lukas on 6/13/2016.
 */
public class DiscordClienthandler {
}
