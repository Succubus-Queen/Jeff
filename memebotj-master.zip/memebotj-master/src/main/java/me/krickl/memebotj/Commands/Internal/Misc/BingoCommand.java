package me.krickl.memebotj.Commands.Internal.Misc;

import me.krickl.memebotj.Channel.ChannelHandler;
import me.krickl.memebotj.Commands.CommandHandler;
import me.krickl.memebotj.Memebot;
import me.krickl.memebotj.User.UserHandler;
import me.krickl.memebotj.Utility.CommandPower;

import java.security.SecureRandom;

/**
 * This file is part of memebotj.
 * Created by unlink on 11/04/16.
 */
public class BingoCommand extends CommandHandler {
    public BingoCommand(ChannelHandler channelHandler, String commandName, String dbprefix) {
        super(channelHandler, commandName, dbprefix);
    }

    @Override
    public void overrideDB() {
        this.setHelptext(Memebot.formatText("BINGO_SYNTAX", getChannelHandler(), null, this, true, new String[]{}, ""));
        this.setEnabled(true);
    }

    @Override
    public void commandScript(UserHandler sender, String[] data) {
        if (data.length >= 1 && checkPermissions(sender, CommandPower.modAbsolute, CommandPower.modAbsolute)) {
            if(data[0].equals("set")) {
                if(data.length >= 2) {
                    getChannelHandler().setCurrentBingoBoard(data[1]);
                }
            } else {
                SecureRandom ran = new SecureRandom();
                String board = getChannelHandler().getBingoURL().replace("{seed}", String.format("%d", Math.abs(ran.nextInt()))).replace("{mode}", data[0]);

                getChannelHandler().setCurrentBingoBoard(board);
            }

            getChannelHandler().sendMessage(getChannelHandler().getCurrentBingoBoard(), this.getChannelHandler().getChannel(),
                    sender, isWhisper());
        } else {
            getChannelHandler().sendMessage(getChannelHandler().getCurrentBingoBoard(), this.getChannelHandler().getChannel(),
                    sender, isWhisper());
        }
    }
}

