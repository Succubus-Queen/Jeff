package me.krickl.memebotj.Channel.Interfaces;

/**
 * Created by unlink on 6/17/2016.
 */
public interface IChannel {
}
