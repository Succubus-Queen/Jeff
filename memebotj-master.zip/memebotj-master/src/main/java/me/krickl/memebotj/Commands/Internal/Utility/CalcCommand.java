package me.krickl.memebotj.Commands.Internal.Utility;

import me.krickl.memebotj.Channel.ChannelHandler;
import me.krickl.memebotj.Commands.CommandHandler;
import me.krickl.memebotj.Log.LogLevels;
import me.krickl.memebotj.Memebot;
import me.krickl.memebotj.User.UserHandler;

/**
 * Created by lukas on 12/14/2016.
 * Solve simple math equations
 * todo make this more complex eventually, cause memes
 */
public class CalcCommand extends CommandHandler {
    public CalcCommand(ChannelHandler channelHandler, String commandName, String dbprefix) {
        super(channelHandler, commandName, dbprefix);
    }

    @Override
    public void overrideDB() {
        setFormatData(true);
    }

    @Override
    public void commandScript(UserHandler sender, String[] data) {
        try {
            String output = "";

           float i1 = Float.parseFloat(data[0]);
           float i2 = Float.parseFloat(data[2]);
           String operand = data[1];

           if(operand.equals("+")) {
               output = String.format("%f %s %f = %f", i1, operand, i2, i1 + i2);
           } else if(operand.equals("-")) {
               output = String.format("%f %s %f = %f", i1, operand, i2, i1 - i2);
           } else if(operand.equals("*")) {
               output = String.format("%f %s %f = %f", i1, operand, i2, i1 * i2);
           } else if(operand.equals("/")) {
               output = String.format("%f %s %f = %f", i1, operand, i2, i1 / i2);
           } else if(operand.equals("%")) {
               output = String.format("%f %s %f = %f", i1, operand, i2, i1 % i2);
           } else {
               output = "CALC_ERROR";
           }

           getChannelHandler().sendMessage(output, getChannelHandler().getChannel(), sender, isWhisper());
        } catch(ArrayIndexOutOfBoundsException | NumberFormatException e) {
            log.log( "calculator error " + e.toString(), LogLevels.ERROR);
            getChannelHandler().sendMessage(e.toString(), getChannelHandler().getChannel(), sender, isWhisper());
        }
    }
}
