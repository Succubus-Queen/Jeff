package me.krickl.memebotj.Utility;

/**
 * Created by lukas on 12/17/2016.
 */
/*
Each channel will have one of these
A JSON will define how bans will be handled
There will be a global list as well
 */
public class AutoModHandler {
}
