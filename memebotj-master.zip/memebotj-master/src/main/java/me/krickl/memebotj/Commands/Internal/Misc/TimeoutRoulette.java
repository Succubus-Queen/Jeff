package me.krickl.memebotj.Commands.Internal.Misc;

/**
 * Created by unlink on 7/15/2016.
 */
public class TimeoutRoulette {
}
