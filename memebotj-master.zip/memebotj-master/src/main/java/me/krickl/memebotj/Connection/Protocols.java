package me.krickl.memebotj.Connection;

/**
 * This file is part of memebotj.
 * Created by lukas on 6/16/2016.
 */
public enum Protocols {
    TMI_TWITCH,
    DISCORD
}
