package me.krickl.memebotj.Commands.Interfaces;

import me.krickl.memebotj.Commands.CommandHandler;
import me.krickl.memebotj.User.UserHandler;

/**
 * This file is part of memebotj.
 * Created by lukas on 10/6/2016.
 * This interface is used to implement new command scripts
 */
public interface ICommandScript {
    void commandScript(CommandHandler command, UserHandler sender, String[] data);
}
