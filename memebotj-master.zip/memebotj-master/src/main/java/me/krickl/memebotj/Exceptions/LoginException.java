package me.krickl.memebotj.Exceptions;

/**
 * This file is part of memebotj.
 * Created by unlink on 20/04/16.
 */
public class LoginException extends Exception {
    public LoginException(String message) {
        super(message);
    }
}
