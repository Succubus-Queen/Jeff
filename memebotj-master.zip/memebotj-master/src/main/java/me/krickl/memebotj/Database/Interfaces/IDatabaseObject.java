package me.krickl.memebotj.Database.Interfaces;

/**
 * This file is part of memebotj.
 * Created by unlink on 02/05/16.
 */
public interface IDatabaseObject {
    void writeDB();

    void readDB();

    void removeDB();

    void setDB();
}
