package me.krickl.memebotj;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.WriteConcern;
import com.mongodb.client.MongoDatabase;
import me.krickl.memebotj.Channel.ChannelHandler;
import me.krickl.memebotj.Channel.TMIChannelHandler;
import me.krickl.memebotj.Commands.CommandHandler;
import me.krickl.memebotj.Commands.CommandReference;
import me.krickl.memebotj.Commands.Interfaces.ICommand;
import me.krickl.memebotj.Connection.Debug.DebugConnectionHandler;
import me.krickl.memebotj.Connection.Interfaces.IConnection;
import me.krickl.memebotj.Connection.Discord.DiscordConnectionHandler;
import me.krickl.memebotj.Connection.TMI.TMIConnectionHandler;
import me.krickl.memebotj.Log.LogLevels;
import me.krickl.memebotj.Log.MLogger;
import me.krickl.memebotj.Plugins.IPlugin;
import me.krickl.memebotj.SpeedrunCom.SpeedRunComAPI;
import me.krickl.memebotj.Twitch.TwitchAPI;
import me.krickl.memebotj.User.UserHandler;
import me.krickl.memebotj.Utility.BuildInfo;
import me.krickl.memebotj.Utility.Localisation;
import me.krickl.memebotj.Utility.TextFormatting;
import me.krickl.memebotj.Web.WebHandler;
import org.json.simple.JSONObject;

import java.io.*;
import java.lang.management.ManagementFactory;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

/**
 * This file is part of memebotj.
 * Created by unlink on 04/04/16.
 */
// todo rewrite main class
public class Memebot {
    public static final int messageLimit = 19; // message limit per 30 seconds
    public static MLogger log = MLogger.createLogger(Memebot.class.getName());
    public static String ircServer = "irc.twitch.tv";
    public static int ircport = 6667;
    public static String mongoHost = "localhost";
    public static int mongoPort = 27017;
    public static String mongoDBName = "memebot";
    public static String home = System.getProperty("user.home");
    public static String memebotDir = "./config";
    public static String htmlDir = "";
    public static String configFile = memebotDir + "/memebot.cfg";
    public static String channelConfig = memebotDir + "/channels.cfg";
    public static String botNick = null;
    public static String botPassword = null;
    public static String clientID = null;
    public static int clientIDValidated = 1;
    public static String clientSecret = null;
    public static List<String> botAdmins = new ArrayList<String>();
    public static String mongoUser = "";
    public static String mongoPassword = "";
    public static boolean useMongoAuth = false;
    public static int pid = 0;
    public static ArrayList<String> channels = new java.util.ArrayList<String>();
    public static ArrayList<String> channelsPrivate = new java.util.ArrayList<String>();
    public static boolean isTwitchBot = true;
    public static boolean jokeMode = false;
    // ConnectionHandler connection = null
    public static List<ChannelHandler> joinedChannels = new ArrayList<ChannelHandler>();
    public static boolean useMongo = true;
    // boolean updateToMongo = false
    public static MongoClient mongoClient = null;
    public static MongoDatabase dbPrivate = null;
    public static MongoDatabase db = null;
    public static int webPort = 4567;
    public static boolean verbose = false;

    public static HashMap<String, IPlugin> plugins = new HashMap<>();

    //public static MongoCollection<Document> internalCollection = null;
    public static String webBaseURL = "";

    public static boolean useWeb = true;

    public static boolean isBotMode = true;

    public static String mainChannel = "#getmemebot"; // this is the home channel of the bot - in this channel people can adopt the bot

    public static boolean debug = false;

    public static boolean useUpdateThread = true;

    public static ArrayList<String> urlBanList = new java.util.ArrayList<String>();

    public static ArrayList<String> globalBanList = new java.util.ArrayList<String>();

    public static ArrayList<String> phraseBanList = new ArrayList<String>();

    public static Localisation defaultLocal = new Localisation("engb");

    public static boolean cliInput = false;

    public static boolean isRunning = true;

    public static boolean debugConnection = false;

    public static String connectionMode = "irc";

    public static String discordOauth = "";

    public static String mailToRecipient = "";
    public static String mailServerAddress = "localhost";
    public static String mailSender = "";
    public static String mailServer = "mail.smtp.host";
    public static int writeConcernLevel = 1;

    public static int logLevel = 0;
    public static String readFrom = "mongo";
    public static String writeTo = "mongo";

    public static void main(String[] args) {
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (arg.contains("home=")) {
                Memebot.home = arg.replaceAll("home=", "");
                Memebot.memebotDir = Memebot.home + "/config";
                Memebot.configFile = Memebot.memebotDir + "/memebot.cfg";
                Memebot.channelConfig = Memebot.memebotDir + "/channels.cfg";
                log.log("Set home directory to " + Memebot.home);
            }
        }

        setupDirs();
        readConfig();
        // wait for this file to be deleted upon exiting
        if(!debug) {
            while (new File(Memebot.memebotDir + "/pid").exists()) {
                try {
                    Thread.sleep(6000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        shutDownHook();
        setupDB();
        WebHandler.webHandler();
        setupConnection();
        mainLoop();
    }

    public static void exit(int exitCode) {
        File lockFile = new File(Memebot.memebotDir + "/pid");
        saveAll();
        if(lockFile.exists()) {
            lockFile.delete();
        }
        log.log("Exiting normally", LogLevels.INFO);
        System.exit(exitCode);
    }

    public static void setupDirs() {
        // initial setup
        new File(memebotDir).mkdir();
        new File(memebotDir + "/channels").mkdir();
        new File(memebotDir + "/locals").mkdir();
        new File(memebotDir + "/logs").mkdir();

        try {
            new File(memebotDir + "/running.lock").createNewFile();
        } catch(IOException e) {
            log.log(e.toString());
        }

        BuildInfo.loadBuildInfo();
    }

    public static void setupDB() {
        if (Memebot.isBotMode) {
            // set up database
            if (Memebot.useMongo) {
                if (Memebot.useMongoAuth) {
                    MongoClientURI authuri = new MongoClientURI(String.format("mongodb://%s:%s@%s/?authSource=%s",
                            Memebot.mongoUser, Memebot.mongoPassword, Memebot.mongoHost, Memebot.mongoDBName));
                    Memebot.mongoClient = new MongoClient(authuri);
                } else {
                    Memebot.mongoClient = new MongoClient(Memebot.mongoHost, Memebot.mongoPort);
                }
                // set write concern level to client
                mongoClient.setWriteConcern(WriteConcern.JOURNALED);

                Memebot.dbPrivate = Memebot.mongoClient.getDatabase(Memebot.mongoDBName);
                Memebot.db = Memebot.mongoClient.getDatabase(Memebot.mongoDBName + "_public");
                //Memebot.internalCollection = Memebot.db.getCollection("#internal#");
            } else {
                new File(Memebot.memebotDir + "/channeldata").mkdirs();
            }

            try {
                channels = Memebot.listDirectory(new File(memebotDir + "/channels/"), 1);
                //private channels on private database
                channelsPrivate = (java.util.ArrayList<String>)
                        Files.readAllLines(Paths.get(Memebot.channelConfig), Charset.defaultCharset());

                urlBanList = (java.util.ArrayList<String>)
                        Files.readAllLines(Paths.get(Memebot.memebotDir + "/urlblacklist.cfg"),
                                Charset.defaultCharset());

                phraseBanList = (java.util.ArrayList<String>)
                        Files.readAllLines(Paths.get(Memebot.memebotDir + "/phrasebanlist.cfg"),
                                Charset.defaultCharset());

                globalBanList = (java.util.ArrayList<String>)
                        Files.readAllLines(Paths.get(Memebot.memebotDir + "/globalbanlist.cfg"),
                                Charset.defaultCharset());

            } catch (IOException e) {
                log.log(e.toString(), LogLevels.ERROR);
            }
        }
    }

    public static void setupConnection() {
        // setup connection

        // todo discord debug code
        DiscordConnectionHandler discordConnectionHandler = new DiscordConnectionHandler(Memebot.discordOauth);
        // todo remove

        // join channels
        Iterator it = Memebot.channels.iterator();
        while (it.hasNext()) {
            String channel = (String) it.next();
            Memebot.joinChannel(channel);
        }

        plugins.put("twitchapi", new TwitchAPI());
        plugins.get("twitchapi").start();
        plugins.put("speedruncomapi", new SpeedRunComAPI());
        plugins.get("speedruncomapi").start();
    }

    public static void mainLoop() {
        //auto rejoin if a thread crashes
        while (Memebot.isRunning) {
            for (int i = 0; i < Memebot.joinedChannels.size(); i++) {
                ChannelHandler ch = Memebot.joinedChannels.get(i);
                if (!ch.getT().isAlive()) {
                    String channel = ch.getChannel();
                    Memebot.joinedChannels.remove(i);
                    Memebot.joinChannel(channel);
                }
            }

            if (!plugins.get("twitchapi").getT().isAlive()) {
                plugins.replace("twitchapi", new TwitchAPI());
                plugins.get("twitchapi").start();
            }

            if (!plugins.get("speedruncomapi").getT().isAlive()) {
                plugins.replace("speedruncomapi", new SpeedRunComAPI());
                plugins.get("speedruncomapi").start();
            }

            // check lock file
            if(!(new File(Memebot.memebotDir + "/running.lock").exists())) {
                exit(0);
            }

            try {
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                log.log(e.toString(), LogLevels.ERROR);
            }
        }
    }

    public static void joinChannel(String channel) {
        try {
            File login = new File(Memebot.memebotDir + "/" + channel.replace("\n\r", "") + ".login");
            IConnection connectionInterface = null;

            if(debugConnection) {
                connectionInterface = new DebugConnectionHandler();
            } else {
                connectionInterface = new TMIConnectionHandler(Memebot.ircServer,
                        Memebot.ircport, Memebot.botNick, Memebot.botPassword);
            }
            if (login.exists()) {
                ArrayList<String> loginInfo = (ArrayList<String>)
                        Files.readAllLines(Paths.get(Memebot.memebotDir + "/" + channel.replace("\n\r", "") + ".login"));

                Memebot.log.log("Found login file for channel " + channel);

                if(debugConnection) {
                    connectionInterface = new DebugConnectionHandler();
                } else {
                    connectionInterface = new TMIConnectionHandler(Memebot.ircServer, Memebot.ircport,
                            loginInfo.get(0).replace("\n", ""), loginInfo.get(1).replace("\n", ""));
                }

                ChannelHandler newChannel = new TMIChannelHandler(channel.replace("\n\r", ""), connectionInterface);
                newChannel.start();
                joinedChannels.add(newChannel);
            } else {
                ChannelHandler newChannel = new TMIChannelHandler(channel.replace("\n\r", ""), connectionInterface);
                newChannel.start();
                joinedChannels.add(newChannel);
            }
        } catch (IOException e) {
            log.log(e.toString(), LogLevels.ERROR);
        }
    }

    public static void readConfig() {
        // read config
        Properties config = new Properties();
        try {
            config.load(new FileReader(Memebot.configFile));
        } catch (FileNotFoundException e) {
            try {
                new File(Memebot.configFile).createNewFile();
                // save properties
            } catch (IOException e1) {
                log.log(e.toString(), LogLevels.ERROR);
            }

            log.log(e.toString(), LogLevels.ERROR);
        } catch (IOException e) {
            log.log(e.toString(), LogLevels.ERROR);
        }

        // read botadmin file
        Memebot.botAdmins.add("#internal#");
        try {
            botAdmins = Files.readAllLines(Paths.get(Memebot.memebotDir + "/botadmins.cfg"));
            botAdmins.add("#internal#");
        } catch (IOException e) {
            log.log(e.toString(), LogLevels.ERROR);
        }

        Memebot.ircServer = config.getProperty("ircserver", Memebot.ircServer);
        Memebot.ircport = Integer.parseInt(config.getProperty("ircport", Integer.toString(Memebot.ircport)));
        Memebot.mongoHost = config.getProperty("mongohost", Memebot.mongoHost);
        Memebot.mongoPort = Integer.parseInt(config.getProperty("mongoport", Integer.toString(Memebot.mongoPort)));
        Memebot.mongoDBName = config.getProperty("mongodbname", Memebot.mongoDBName);
        Memebot.botNick = config.getProperty("botnick", Memebot.botNick);
        Memebot.botPassword = config.getProperty("botpassword", Memebot.botPassword);
        Memebot.clientID = config.getProperty("clientid", Memebot.clientID);
        Memebot.clientSecret = config.getProperty("clientsecret", Memebot.clientSecret);
        Memebot.htmlDir = config.getProperty("htmldir", Memebot.htmlDir);
        Memebot.mongoUser = config.getProperty("mongouser", Memebot.mongoUser);
        Memebot.mongoPassword = config.getProperty("mongopassword", Memebot.mongoPassword);
        Memebot.useMongoAuth = Boolean.parseBoolean(config.getProperty("mongoauth",
                Boolean.toString(Memebot.useMongoAuth)));
        Memebot.webBaseURL = config.getProperty("weburl", Memebot.webBaseURL);
        Memebot.useWeb = Boolean.parseBoolean(config.getProperty("useweb", Boolean.toString(Memebot.useWeb)));
        Memebot.useMongo = Boolean.parseBoolean(config.getProperty("usemongo", Boolean.toString(Memebot.useMongo)));
        Memebot.isTwitchBot = Boolean.parseBoolean(config.getProperty("istwitchbot",
                Boolean.toString(Memebot.isTwitchBot)));
        Memebot.mainChannel = config.getProperty("mainchannel", Memebot.mainChannel);
        Memebot.debug = Boolean.parseBoolean(config.getProperty("debug", Boolean.toString(Memebot.debug)));
        Memebot.useUpdateThread = Boolean.parseBoolean(config.getProperty("updatethread",
                Boolean.toString(Memebot.useUpdateThread)));
        Memebot.jokeMode = Boolean.parseBoolean(config.getProperty("joke", Boolean.toString(Memebot.jokeMode)));
        Memebot.webPort = Integer.parseInt(config.getProperty("webport", Integer.toString(Memebot.webPort)));
        Memebot.cliInput = Boolean.parseBoolean(config.getProperty("climode", Boolean.toString(Memebot.cliInput)));
        Memebot.connectionMode = config.getProperty("connectionmode", Memebot.connectionMode);
        Memebot.discordOauth = config.getProperty("discordOauth", discordOauth);
        Memebot.mailToRecipient = config.getProperty("mailtorecipient", mailToRecipient);
        Memebot.mailServer = config.getProperty("mailserveraddress", mailServer);
        Memebot.mailSender = config.getProperty("mailsender", mailSender);
        Memebot.mailServer = config.getProperty("mailserver", mailServer);
        Memebot.writeConcernLevel = Integer.parseInt(config.getProperty("writeConcernLevel", Integer.toString(writeConcernLevel)));
        Memebot.verbose = Boolean.parseBoolean(config.getProperty("verbose", Boolean.toString(verbose)));
        Memebot.debugConnection = Boolean.parseBoolean(config.getProperty("offlinemode", Boolean.toString(verbose)));
        Memebot.writeTo = config.getProperty("writeto", writeTo);
        Memebot.readFrom = config.getProperty("readfrom", readFrom);
        Memebot.logLevel = Integer.parseInt(config.getProperty("loglevel", Integer.toString(logLevel)));

        if (!Memebot.debug) {
            try {
                File f = new File(Memebot.memebotDir + "/logs/#bot#.log");
                if (!f.exists())
                    f.createNewFile();
                PrintStream writer = new PrintStream(new FileOutputStream(f), true);
                System.setOut(writer);
                System.setErr(writer);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void shutDownHook() {
        if (Memebot.isBotMode) {
            // shutdown hook
            Runtime.getRuntime().addShutdownHook(new Thread() {
                @Override
                public void run() {
                    Memebot.log.log("Process received SIGTERM...");
                    saveAll();
                }
            });
        }

        // get pid and write to file
        File f = new File(memebotDir + "/pid");
        BufferedWriter bw = null;
        try {
            Memebot.log.log("PID: " + ManagementFactory.getRuntimeMXBean().getName());
            bw = new BufferedWriter(new FileWriter(f));
            bw.write(ManagementFactory.getRuntimeMXBean().getName().split("@")[0]);
            bw.close();
        } catch (IOException e) {
            log.log(e.toString(), LogLevels.ERROR);
        }
    }

    public static void saveAll() {
        Iterator it = Memebot.joinedChannels.iterator();
        while (it.hasNext()) {
            ChannelHandler ch = (ChannelHandler) it.next();
            ch.writeDB();
            for (CommandReference commandHandler : ch.getChannelCommands()) {
                commandHandler.writeDB();
            }

            for (CommandHandler commandHandler : ch.getInternalCommands()) {
                commandHandler.writeDB();
            }

            for (String userHandler : ch.getUserList().keySet()) {
                ch.getUserList().get(userHandler).writeDB();
            }
            ch.setJoined(false);
        }
    }

    public static String[] parseParameters(String toParse) {
        String[] parsedTemp = toParse.replace("{", "").replace("}", "").split(";");
        String[] parsed = new String[parsedTemp.length];

        for (int i = 0; i < parsedTemp.length; i++) {
            if (i != 0 && i != 1) {
                parsed[i] = parsedTemp[i];
            } else if (i == 1) {
                parsed[i] = "{" + parsedTemp[i] + "}";
            } else {
                parsed[i] = toParse;
            }
        }


        return parsed;
    }

    /**
     * @deprecated This method is replaced by
     * {@link TextFormatting#format(String, ChannelHandler, UserHandler, CommandHandler, boolean, String[], String)}
     */
    public static String formatText(String fo, ChannelHandler channelHandler, UserHandler sender,
                                    CommandHandler commandHandler, boolean local, String[] params, String alternativeText) {
        return TextFormatting.format(fo, channelHandler, sender, commandHandler, local, params, alternativeText);
    }

    /***
     * This class will load the internal commands from external classes
     * This way commands can be reloaded dynamically without a bot restart
     * @return
     */
    public static ArrayList<ICommand> loadPluginCommands() throws MalformedURLException, ClassNotFoundException {
        ArrayList<ICommand> commands = new ArrayList<>();

        return commands;
    }

    /***
     * Reads from URL
     *
     * @param urlString The URL
     * @return String of content
     * @deprecated
     */
    public static String urlRequest(String urlString) {
        return urlRequest(urlString, 5000, false, "GET", "");
    }

    public static String urlRequest(String urlString, int timeout, boolean appendLineFeed) {
        return urlRequest(urlString, timeout, appendLineFeed, "GET", "");
    }

    public static String urlRequest(String urlString, int timeout, boolean appendLineFeed, String requestMethod,
                                    String urlParameters) {
        URL url;
        HttpURLConnection connection = null;
        byte[] sendData = urlParameters.getBytes(StandardCharsets.UTF_8);
        int sendLen = sendData.length;
        String data = "";
        BufferedReader in;
        try {
            url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(timeout);
            connection.setRequestMethod(requestMethod);
            if (requestMethod.equals("POST") || requestMethod.equals("PUT")) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setRequestProperty("Content-Length", Integer.toString(sendLen));
            }
            connection.setRequestProperty("charset", "utf-8");
            connection.setUseCaches(false);

            if (requestMethod.equals("POST") || requestMethod.equals("PUT")) {
                try (DataOutputStream wr = new DataOutputStream(connection.getOutputStream())) {
                    wr.write(sendData);
                    wr.flush();
                    wr.close();
                }
            }

            boolean isError = connection.getResponseCode() >= 400;

            if (!isError) {
                in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            } else {
                in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            }

            String line;
            while ((line = in.readLine()) != null) {
                if (appendLineFeed) {
                    data = data + line + "\n";
                } else {
                    data = data + line;
                }
            }

            in.close();
        } catch (IOException e) {
            log.log(e.toString(), LogLevels.ERROR);
            data = e.toString();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        return data;
    }

    public static byte[] urlRequestBytes(String urlString, int timeout) {
        return urlRequestBytes(urlString, timeout, "GET", "");
    }

    public static byte[] urlRequestBytes(String urlString, int timeout, String requestMethod, String urlParameters) {
        URL url;
        HttpURLConnection connection = null;
        byte[] data = new byte[1024];
        byte[] sendData = urlParameters.getBytes(StandardCharsets.UTF_8);
        int sendLen = sendData.length;
        InputStream in;
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        try {
            url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(timeout);
            connection.setRequestMethod(requestMethod);
            if (requestMethod.equals("POST") || requestMethod.equals("PUT")) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setRequestProperty("Content-Length", Integer.toString(sendLen));
            }
            connection.setRequestProperty("charset", "utf-8");
            connection.setUseCaches(false);

            if (requestMethod.equals("POST") || requestMethod.equals("PUT")) {
                try (DataOutputStream wr = new DataOutputStream(connection.getOutputStream())) {
                    wr.write(sendData);
                    wr.flush();
                    wr.close();
                }
            }

            boolean isError = connection.getResponseCode() >= 400;

            if (!isError) {
                in = connection.getInputStream();
            } else {
                in = connection.getErrorStream();
            }

            int bytesRead = 0;

            while ((bytesRead = in.read(data)) != -1) {
                bao.write(data, 0, bytesRead);
            }

            in.close();
            bao.close();
        } catch (IOException e) {
            log.log(e.toString(), LogLevels.ERROR);
            return e.toString().getBytes();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        return bao.toByteArray();
    }

    /***
     * @param dir
     * @param mode 1 = list all files, 2 = list all directories, 0 = list both
     * @return
     */
    public static ArrayList<String> listDirectory(File dir, int mode) {
        ArrayList<String> dirList = new ArrayList<>();

        File listFiles[] = dir.listFiles();
        if (listFiles == null) {
            return dirList;
        }
        for (final File entry : listFiles) {
            if (entry.isDirectory()) {
                if (mode == 0 || mode == 2) {
                    dirList.add(entry.getName());
                }
            } else {
                if (mode == 0 || mode == 1) {
                    dirList.add(entry.getName());
                }
            }
        }

        return dirList;
    }

    public static JSONObject toJSONObject() {
        JSONObject wrapper = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("channels", Memebot.webBaseURL + "/api/channels");
        jsonObject.put("_id", BuildInfo.appName);
        jsonObject.put("version", BuildInfo.version);
        jsonObject.put("dev", BuildInfo.dev);

        wrapper.put("data", jsonObject);
        wrapper.put("links", getLinks(Memebot.webBaseURL + "/api", null, null, null));

        return wrapper;
    }

    public static JSONObject getLinks(String self, String parent, String next, String previous) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("self", self);
        jsonObject.put("parent", parent);
        jsonObject.put("next", next);
        jsonObject.put("previous", previous);

        return jsonObject;
    }

    public static String toJSONString() {
        return toJSONObject().toJSONString();
    }

    public boolean fromJSON(String jsonString) {
        return false;
    }
}
