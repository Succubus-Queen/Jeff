package me.krickl.memebotj.Utility.Joke;

/**
 * Created by lukas on 12/14/2016.
 */
public class AprilFools2017 {
    public static String stringToHexString(String input) {
        char[] raw = input.toCharArray();
        StringBuilder strBuilder  = new StringBuilder();

        for(int i = 0; i < raw.length; i++) {
            if(raw[i] <= 0x000F) {
                strBuilder.append("000");
            } else if(raw[i] <= 0x00FF) {
                strBuilder.append("00");
            } else if(raw[i] <= 0x0FFF) {
                strBuilder.append("0");
            }
            strBuilder.append(Integer.toHexString(raw[i]).toUpperCase());
        }

        return strBuilder.toString();
    }
}
