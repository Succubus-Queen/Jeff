package me.krickl.memebotj.Exceptions;

/**
 * This file is part of memebotj.
 * Created by lukas on 8/1/2016.
 */
public class MiniOvenException extends Exception {
    public MiniOvenException() {
        super("M I N I O V E N  B R O U G H T  T O  Y O U  B Y  F U L L  M I N I O V E N  C O N V E R T E R");
    }
}
