package me.krickl.memebotj.Utility;

import me.krickl.memebotj.Channel.ChannelHandler;
import me.krickl.memebotj.Commands.CommandHandler;
import me.krickl.memebotj.Commands.CommandReference;
import me.krickl.memebotj.Memebot;
import me.krickl.memebotj.User.UserHandler;
import me.krickl.memebotj.Web.WebHandler;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This file is part of memebotj.
 * Created by Luigitus on 26/09/16.
 */
public class TextFormatting {

    public static String[] createParams(String... params) {
        if (params == null) {
            return new String[]{};
        }
        return params;
    }

    public static String format(String fo, ChannelHandler channelHandler, UserHandler sender,
                                CommandHandler commandHandler) {
        return format(fo, channelHandler, sender, commandHandler, true, createParams(), "");
    }

    public static String format(String fo, ChannelHandler channelHandler, UserHandler sender,
                                CommandHandler commandHandler, boolean local) {
        return format(fo, channelHandler, sender, commandHandler, local, createParams(), "");
    }

    public static String format(String fo, ChannelHandler channelHandler, UserHandler sender,
                                CommandHandler commandHandler, String[] params) {
        return format(fo, channelHandler, sender, commandHandler, true, params, "");
    }

    public static String format(String fo, ChannelHandler channelHandler, UserHandler sender,
                                CommandHandler commandHandler, boolean local, String[] params) {
        return format(fo, channelHandler, sender, commandHandler, local, params, "");
    }

    public static String format(String fo, ChannelHandler channelHandler, UserHandler sender,
                                CommandHandler commandHandler, boolean local, String[] params,
                                String alternativeText) {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd"); // dd/MM/yyyy
        Calendar cal = Calendar.getInstance();
        String strDate = sdfDate.format(cal.getTime());
        String formattedOutput = fo;

        SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm:ss a");
        Calendar calTime = Calendar.getInstance();
        String strTime = sdfTime.format(calTime.getTime());

        SecureRandom ran = new SecureRandom();

        boolean containsNone = false;
        if (formattedOutput.contains("{none}")) {
            containsNone = true;
        }

        if (local && channelHandler != null) {
            formattedOutput = channelHandler.getLocalisation().localisedStringFor(fo);
        }

        if (sender != null) {
            formattedOutput = formattedOutput.replace("{sender}", sender.screenName());
            formattedOutput = formattedOutput.replace("{senderusername}", sender.getUsername());
            formattedOutput = formattedOutput.replace("{points}", String.format("%.2f", sender.getPoints()));
            formattedOutput = formattedOutput.replace("{debugsender}", sender.toString());

            while(formattedOutput.contains("{randompoints}")) {
                int newRan = new Double(sender.getPoints()).intValue();

                if (newRan > 0) {
                    formattedOutput = formattedOutput.replaceFirst("(\\{randompoints\\})",
                            Integer.toString(Math.abs(ran.nextInt(newRan))));
                } else {
                    formattedOutput = formattedOutput.replaceFirst("(\\{randompoints\\})",
                            Integer.toString(Math.abs(ran.nextInt(newRan + 1))));
                }
            }
        }
        if (commandHandler != null) {
            formattedOutput = formattedOutput.replace("{counter}", Integer.toString(commandHandler.getCounter()));
            formattedOutput = formattedOutput.replace("{debugch}", commandHandler.toString());
            formattedOutput = formattedOutput.replace("{execcount}", Integer.toString(commandHandler.getExecCounter()));
        }
        if (channelHandler != null) {
            formattedOutput = formattedOutput.replace("{broadcaster}", channelHandler.getBroadcaster());
            formattedOutput = formattedOutput.replace("{channelweb}", channelHandler.getChannelPageBaseURL());
            if (channelHandler.getCurrentGame() != null) {
                formattedOutput = formattedOutput.replace("{game}", channelHandler.getCurrentGame());
            }
            if (channelHandler.getStreamTitle() != null) {
                formattedOutput = formattedOutput.replace("{title}", channelHandler.getStreamTitle());
            }
            formattedOutput = formattedOutput.replace("{curremote}",
                    channelHandler.getCurrencyEmote());
            formattedOutput = formattedOutput.replace("{currname}",
                    channelHandler.getCurrencyName());
            formattedOutput = formattedOutput.replace("{botnick}", channelHandler.getConnection().getBotNick());

            // random user as parameter
            List<String> keys = new ArrayList<String>(channelHandler.getUserList().keySet());
            UserHandler randomUH = null;
            if (sender != null && commandHandler != null) {
                if (commandHandler.checkPermissions(sender, CommandPower.adminAbsolute, CommandPower.adminAbsolute)) {
                    while(formattedOutput.contains("{randomuserall}")) {
                        randomUH = channelHandler.getUserList().getOrDefault(keys.get(ran.nextInt(keys.size())),
                                new UserHandler("#internal#", channelHandler.getChannel()));
                        formattedOutput = formattedOutput.replaceFirst("(\\{randomuserall\\})", randomUH.getUsername());
                    }
                }
            }

            // todo random user as parameter
            ArrayList<UserHandler> activeUsers = new ArrayList<>();
            for (String key : keys) {
                if (channelHandler.getUserList().get(key).isActive()) {
                    activeUsers.add(channelHandler.getUserList().get(key));
                }
            }

            while(formattedOutput.contains("{randomuser}")) {
                randomUH = activeUsers.get(ran.nextInt(activeUsers.size()));
                formattedOutput = formattedOutput.replaceFirst("(\\{randomuser\\})", randomUH.getUsername());
            }

            while(formattedOutput.contains("{randomuserdb}")) {
                if (formattedOutput.contains("{randomuserdb}")) {
                    // random user from database
                    ArrayList<String> userList = WebHandler.getUserListFromDB(channelHandler.getChannel());
                    formattedOutput = formattedOutput.replaceFirst("(\\{randomuserdb\\})", userList.get(ran.nextInt(userList.size())));
                }
            }


            // random USSR as parameter - returns your favourite communist leader
            String[] keysUSSR = {"Vladimir Lenin", "Joseph Stalin", "Georgy Malenkov", "Nikita Khrushchev",
                    "Leonid Brezhnev", "Yuri Andropov", "Konstantin Chernenko", "Mikhail Gorbachev",
                    "Gennady Yanayev", "The man who arranges the blocks which continue to fall from up above",
            "Pavel Belyayev", "Aleksei Leonov", "Musa Manarov"};
            String randomUSSRString = keysUSSR[ran.nextInt(keysUSSR.length)];
            formattedOutput = formattedOutput.replace("{randomUSSR}", randomUSSRString);

            // todo add this later
            // command output as parameter
            /*for(CommandReference ch : channelHandler.getChannelCommands()) {
                if(formattedOutput.contains("{" + ch.getCommandName() + "}")) {
                    ch.executeCommand(sender, new String[]{});
                    formattedOutput = formattedOutput.replace("{" + ch.getCommandName() + "}", ch.getCommandHandler().getLastOutput());
                }
            }

            // internal command output as parameter
            for(CommandHandler ch : channelHandler.getInternalCommands()) {
                if(formattedOutput.contains("{" + ch.getCommandName() + "}")) {
                    ch.executeCommand(sender, new String[]{});
                    formattedOutput = formattedOutput.replace("{" + ch.getCommandName() + "}", ch.getLastOutput());
                }
            }*/
        }

        formattedOutput = formattedOutput.replace("{version}", BuildInfo.version);
        formattedOutput = formattedOutput.replace("{developer}", BuildInfo.dev);
        formattedOutput = formattedOutput.replace("{appname}", BuildInfo.appName);
        formattedOutput = formattedOutput.replace("{build}", BuildInfo.buildNumber);
        formattedOutput = formattedOutput.replace("{builddate}", BuildInfo.timeStamp);
        formattedOutput = formattedOutput.replace("{date}", strDate);
        formattedOutput = formattedOutput.replace("{time}", strTime);
        formattedOutput = formattedOutput.replace("{space}", " ");
        formattedOutput = formattedOutput.replace("{}", " ");
        formattedOutput = formattedOutput.replace("{none}", "");

        while(formattedOutput.contains("{random}")) {
            formattedOutput = formattedOutput.replaceFirst("\\{random\\}", Integer.toString(Math.abs(ran.nextInt())));
        }
        formattedOutput = formattedOutput.replace("NO_OUTPUT_ERR()", ""); // workaround to replace this since it was added by accident

        // special random case with max and min
        int max = 0, min = 0;
        int randomRange = 2;

        Matcher matcher = null;

        while((matcher = matchRandom(formattedOutput)).find()) {
            HashMap<String, String> randomResults = getResultsRandom(matcher);
            if(randomResults.containsKey("int1")) {
                min = Integer.parseInt(randomResults.get("int1"));
            }

            if(randomResults.containsKey("int2")) {
                max = Integer.parseInt(randomResults.get("int2"));
            }

            formattedOutput = formattedOutput.replace(String.format("{random;%d;%d}", min, max),
                    Integer.toString(Math.abs(ran.nextInt((max - min) + 1) + min)));
        }


        String paramN = "";

        if (params != null) {
            for (int i = 0; i < params.length; i++) {
                String str = params[i];
                String original = formattedOutput;
                if (str != null) {
                    formattedOutput = formattedOutput.replace(String.format("{param%d}", i + 1), str);

                    if (formattedOutput.equals(original) && !formattedOutput.contains("{paramN}")) {
                        formattedOutput = formattedOutput + " " + str;
                    } else if (formattedOutput.equals(original)) {
                        paramN = paramN + str + " ";
                    }
                } else if (alternativeText != null) {
                    formattedOutput = alternativeText;
                }
            }
        }

        // insert paramN
        formattedOutput = formattedOutput.replace("{paramN}", paramN);

        if (formattedOutput.isEmpty() && !containsNone && Memebot.debug) {
            if(Memebot.verbose) {
                formattedOutput = "NO_OUTPUT_ERR()";
            } else {
                formattedOutput = "";
            }
        }

        return formattedOutput;
    }

    // URL that generated this code:
    // http://txt2re.com/index-java.php3?s={random;1;2}&3&6&7&-19&4&5&2&-26&-27&-18
    public static Matcher matchRandom(String txt) {
        String re1="(\\{)";	// Any Single Character 1
        String re2= "(random)"; // "((?:[a-z][a-z]+))";	// Word 1
        String re3="(;)";	// Any Single Character 2
        String re4="(\\d+)";	// Integer Number 1
        String re5="(;)";	// Any Single Character 3
        String re6="(\\d+)";	// Integer Number 2
        String re7="(\\})";	// Any Single Character 4

        Pattern p = Pattern.compile(re1+re2+re3+re4+re5+re6+re7,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher m = p.matcher(txt);

        return m;
    }

    public static HashMap<String, String> getResultsRandom(Matcher m) {
        HashMap<String, String> results = new HashMap<>();

        //if (m.find())
        //{
            String c1=m.group(1);
            String word1=m.group(2);
            String c2=m.group(3);
            String int1=m.group(4);
            String c3=m.group(5);
            String int2=m.group(6);
            String c4=m.group(7);

            results.put("word1", word1);
            results.put("c1", c1);
            results.put("c2", c2);
            results.put("c3", c3);
            results.put("c4", c4);
            results.put("int1", int1);
            results.put("int2", int2);
        //}

        return results;
    }
}